//Split this Application Class into an Application and an Object
public class CaesarCipherApp {

  public static void main(String[] args) {
    System.out.println("*********************************************************\n\n");
    String plainText = "Happy Holidays 2022!";
    String cipherText = encode(plainText, 3);
    String decodedText = decode(cipherText, 3);
    System.out.println("PlainText =   " + plainText);
    System.out.println("CipherText =  " + cipherText);
    System.out.println("DecodedText = " + decodedText);
  }

  public static String encode(String in, int shiftAmt) {
    String upper = in.toUpperCase();

    String answer = "";
    for (int i = 0; i < in.length(); i++) {
      if (Character.isLetter(upper.charAt(i))) {
        char ch = (char) (upper.charAt(i) + shiftAmt);
        if (ch > 'Z') {
          ch = (char) (ch - 26);
        }
        if (Character.isLowerCase(in.charAt(i))) {
          ch = Character.toLowerCase(ch);
        }
        answer += ch;
      } else {
        answer += upper.charAt(i);
      }
    }
    return answer;
  }

  public static String decode(String in, int shiftAmt) {
    shiftAmt = 26 - shiftAmt;
    String answer = encode(in, shiftAmt);
    shiftAmt = 26 - shiftAmt;
    return answer;
  }
}