// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;
import java.util.Scanner;
import Ciphers.*;
//it was only printing hello world for some reason so avadhut told me to do this so it imports all classese from cipher
public class Main{
  public static void main(String[] args) {
    System.out.println("Substitution, Caesar, or other?");
    Scanner scanner = new Scanner(System.in);
    String type = scanner.nextLine();
    if (type.equals("Caesar")) {
      System.out.println("Enter a message and shift to encode or decode.");
      Scanner sc = new Scanner(System.in);
      Scanner ab = new Scanner(System.in);
      String message = sc.nextLine();
      int shift = ab.nextInt();
      System.out.println("Enter 1 to encode or 2 to decode.");
      Scanner cd = new Scanner(System.in);
      int choice = cd.nextInt();
      caesarCipher cc = new caesarCipher(shift);
      if (choice == 1) {
        System.out.println(cc.encode(message));
      }
      if (choice == 2) {
        System.out.println(cc.decode(message));
      }
      else {
        System.out.println("Enter either one or two.");
      }
      try {
        System.out.println(cc.encode(message));
      }
      catch (Exception e) {
        System.out.println("Illegal argument exception. Enter a string message and a positive integer shift.");
        
      }
    }
    if (type.equals("Substitution")) {
      System.out.println("Enter a message and a key in the form of abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZa to encode or decode.");
      Scanner ac = new Scanner(System.in);
      String key = ac.nextLine();
      Scanner xy = new Scanner(System.in);
      String message = xy.nextLine();
      substitutionCipher sc = new substitutionCipher(key);
      System.out.println("Enter 1 to encode or 2 to decode.");
      Scanner bd = new Scanner(System.in);
      int choice = bd.nextInt();
      
      if (choice == 1) {
        System.out.println(sc.encode(message));
      }
      else if (choice == 2) {
        System.out.println(sc.decode(message));
      }
      else {
        System.out.println("Enter either 1 or two");
      }
      try {
        System.out.println(sc.encode(message));
      }
      catch (Exception e) {
        System.out.println("Enter a string message and a key in the form of abcdefghijklmnopqrstuvwxyzABCDEFG");
      }
    }
    // System.out.println("Hello world!");
  }

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }
}